package com.whatwillieat.meals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MealsApplicationTests {

	@Test
	void contextLoads() {
	}

}
