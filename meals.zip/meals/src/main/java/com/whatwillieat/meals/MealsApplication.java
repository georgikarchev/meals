package com.whatwillieat.meals;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MealsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MealsApplication.class, args);
	}

}
